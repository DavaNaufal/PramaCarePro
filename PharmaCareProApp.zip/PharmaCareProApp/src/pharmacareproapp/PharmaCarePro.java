package pharmacareproapp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class PharmaCarePro {
    private JFrame frame;
    private JTextField tfUsername, tfPassword, tfNamaObat, tfDosis;
    private JTextArea taDaftarObat;
    private JTextArea taResep;
    private ArrayList<Obat> daftarObat;
    private ArrayList<String> daftarResep;
    private ArrayList<KategoriObat> daftarKategoriObat;
    private final String user = "admin";
    private final String pass = "admin123";
    private JList<Obat> listObat;
    private JComboBox<KategoriObat> cbKategoriObat;
    public static class Obat {
        private String nama;
        private String dosis;
        private String informasi;
        private int jumlahStok;

        public Obat(String nama, String dosis, String informasi) {
            this.nama = nama;
            this.dosis = dosis;
            this.informasi = informasi;
            this.jumlahStok = 0; // set stok awal ke 0
        }
        @Override
        public String toString() {
            return nama + " - Dosis: " + dosis + " - Stok: " + jumlahStok;
        }

        // Getter dan setter
        public String getNama() {
            return nama;
        }

        public void setNama(String nama) {
            this.nama = nama;
        }

        public String getDosis() {
            return dosis;
        }

        public void setDosis(String dosis) {
            this.dosis = dosis;
        }

        public String getInformasi() {
            return informasi;
        }

        public void setInformasi(String informasi) {
            this.informasi = informasi;
        }
        public int getJumlahStok() {
            return jumlahStok;
        }

        public void setJumlahStok(int jumlahStok) {
            this.jumlahStok = jumlahStok;
        }        
        public void tambahStok(int jumlah) {
            this.jumlahStok += jumlah;
        }

        public void kurangiStok(int jumlah) {
            this.jumlahStok -= jumlah;
            if (this.jumlahStok < 0) {
                this.jumlahStok = 0; // Pastikan stok tidak kurang dari 0
            }
        }
    }
    public static class KategoriObat {
        private String namaKategori;
        private ArrayList<Obat> daftarObat;

        public KategoriObat(String namaKategori) {
            this.namaKategori = namaKategori;
            this.daftarObat = new ArrayList<>();
        }

        public void tambahObat(Obat obat) {
            daftarObat.add(obat);
        }
        @Override
        public String toString() {
            return namaKategori;
        }

    }
    public PharmaCarePro() {
        daftarObat = new ArrayList<>();
        daftarResep = new ArrayList<>();
        daftarKategoriObat = new ArrayList<>();
        
        // Inisialisasi kategori dan tambahkan obat ke kategori
        KategoriObat obatBatukPilek = new KategoriObat("Obat Batuk Pilek");
        KategoriObat obatPusing = new KategoriObat("Obat Pusing");
        KategoriObat obatMata = new KategoriObat("Obat Mata");
        KategoriObat obatSakitPerut = new KategoriObat("Obat Sakit Perut");
        Obat obat = new Obat("Actifed Plus Expectorant", "2 kali sehari setelah makan", "Informasi tentang obat ini");
        obat.setJumlahStok(6);
        obatBatukPilek.tambahObat(obat);
        // ... Tambahkan obat lainnya dan kategori lainnya sesuai kebutuhan
        daftarKategoriObat.add(obatBatukPilek);
        daftarKategoriObat.add(obatPusing);
        daftarKategoriObat.add(obatMata);
        daftarKategoriObat.add(obatSakitPerut);
                // Menambahkan contoh obat dan dosisnya
        showLogin();
        
    }

    private void showLogin() {
        frame = new JFrame("Login");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel lblUsername = new JLabel("Username:");
        tfUsername = new JTextField(20);
        JLabel lblPassword = new JLabel("Password:");
        tfPassword = new JPasswordField(20);
        JButton btnLogin = new JButton("Login");

        frame.add(lblUsername);
        frame.add(tfUsername);
        frame.add(lblPassword);
        frame.add(tfPassword);
        frame.add(btnLogin);

        btnLogin.addActionListener(e -> {
            if (tfUsername.getText().equals(user) && md5(tfPassword.getText()).equals(md5(pass))) {
                frame.dispose();
                showMainMenu();
            } else {
                JOptionPane.showMessageDialog(frame, "Username atau Password salah!");
            }
        });
        frame.setVisible(true);
    }

    private void showMainMenu() {
        frame = new JFrame("PharmaCare Pro - Menu Utama");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JButton btnStokObat = new JButton("Manajemen Stok Obat");
        JButton btnLihatDosis = new JButton("Lihat Dosis");
        JButton btnLogout = new JButton("Logout");
        JButton btnPencarianObat = new JButton("Pencarian Obat");
        JButton btnFormResep = new JButton("Form Resep dan Pelayanan Pasien");
        JButton btnDashboard = new JButton("Dashboard");
        JButton btnLaporan = new JButton("Laporan");        
        frame.add(btnStokObat);
        frame.add(btnLihatDosis);
        frame.add(btnLogout);
        frame.add(btnPencarianObat);  // Tambahkan tombol ke frame
        frame.add(btnFormResep);
        frame.add(btnDashboard);
        frame.add(btnLaporan);
        btnStokObat.addActionListener(e -> {
            frame.dispose();
            showStokObat();
        });

        btnLihatDosis.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "Fitur Lihat Dosis belum diimplementasikan.");
        });

        btnLogout.addActionListener(e -> {
            frame.dispose();
            showLogin();
        });
        
        btnPencarianObat.addActionListener(e -> {
            frame.dispose();
            showPencarianObat();
        });

        btnFormResep.addActionListener(e -> {
            frame.dispose();
            showFormResep();
        });
        frame.setVisible(true);
        btnDashboard.addActionListener(e -> {
            frame.dispose();
            showDashboard();
        });

        btnLaporan.addActionListener(e -> {
            frame.dispose();
            showLaporan();
        });
    }

    private void showStokObat() {
        // Implementasi sederhana dari manajemen stok obat
        frame = new JFrame("Manajemen Stok Obat");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        cbKategoriObat = new JComboBox<>();
        for (KategoriObat kategori : daftarKategoriObat) {
            cbKategoriObat.addItem(kategori);
        }
        frame.add(new JLabel("Kategori Obat:"));
        frame.add(cbKategoriObat);

        tfNamaObat = new JTextField(20);
        tfDosis = new JTextField(20);
        JTextField tfStok = new JTextField(20);
        JButton btnTambah = new JButton("Tambah Obat");
        JButton btnTambahStok = new JButton("Tambah Stok");
        JButton btnKurangiStok = new JButton("Kurangi Stok");
        JButton btnHapusObat = new JButton("Hapus Obat");
        taDaftarObat = new JTextArea(10, 40);
        taDaftarObat.setEditable(false);
        JButton btnKembali = new JButton("Kembali ke Menu Utama");
        listObat = new JList<>(new DefaultListModel<>());




        frame.add(new JLabel("Nama Obat:"));
        frame.add(tfNamaObat);
        frame.add(new JLabel("Dosis:"));
        frame.add(tfDosis);
        frame.add(btnTambah);
        frame.add(new JLabel("Stok:"));
        frame.add(tfStok);
        frame.add(new JScrollPane(listObat));
        frame.add(btnKembali);
        frame.add(btnTambahStok);
        frame.add(btnKurangiStok);
        frame.add(btnHapusObat);


        btnTambah.addActionListener(e -> {
            String namaObat = tfNamaObat.getText();
            String dosis = tfDosis.getText();
            Obat obatBaru = new Obat(namaObat, dosis, "Informasi tambahan tentang obat ini");
            daftarObat.add(obatBaru);

            // Juga tambahkan obat ke kategori yang dipilih
            KategoriObat kategoriTerpilih = (KategoriObat) cbKategoriObat.getSelectedItem();
            if (kategoriTerpilih != null) {
                kategoriTerpilih.tambahObat(obatBaru);
            }

            updateDaftarObat();
        });

        btnKembali.addActionListener(e -> {
            frame.dispose();
            showMainMenu();
        });
        btnTambahStok.addActionListener(e -> {
            Obat obatTerpilih = listObat.getSelectedValue();
            if (obatTerpilih != null) {
                int stokBaru = Integer.parseInt(tfStok.getText());
                obatTerpilih.tambahStok(stokBaru);
                updateDaftarObat();
            }
        });

        btnKurangiStok.addActionListener(e -> {
            Obat obatTerpilih = listObat.getSelectedValue();
            if (obatTerpilih != null) {
                int stokKurang = Integer.parseInt(tfStok.getText());
                obatTerpilih.kurangiStok(stokKurang);
                updateDaftarObat();
            }
        });
        btnHapusObat.addActionListener(e -> {
            Obat obatTerpilih = listObat.getSelectedValue();
            if (obatTerpilih != null) {
                daftarObat.remove(obatTerpilih);
                updateDaftarObat();
            }
        });




        updateDaftarObat();  // Tambahkan baris ini
        
        frame.setVisible(true);
    }

    private void updateDaftarObat() {
        DefaultListModel<Obat> model = (DefaultListModel<Obat>) listObat.getModel();
        model.clear();
        for (Obat obat : daftarObat) {
            model.addElement(obat);
        }

    }
    private String md5(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PharmaCarePro());
    }
    private void showPencarianObat() {
        frame = new JFrame("Pencarian Obat");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField tfCari = new JTextField(20);
        JButton btnCari = new JButton("Cari");
        JTextArea taHasilCari = new JTextArea(10, 40);
        taHasilCari.setEditable(false);
        JButton btnKembali = new JButton("Kembali");

        frame.add(new JLabel("Masukkan nama obat:"));
        frame.add(tfCari);
        frame.add(btnCari);
        frame.add(new JScrollPane(taHasilCari));
        frame.add(btnKembali);

        btnCari.addActionListener(e -> {
            String query = tfCari.getText().toLowerCase();
            StringBuilder sb = new StringBuilder();
        for (Obat obatItem : daftarObat) {
            if (obatItem.getNama().toLowerCase().contains(query)) {
                sb.append(obatItem).append("\n");  // Akan memanggil metode toString() dari kelas Obat
            }
        }
            taHasilCari.setText(sb.toString());
        });

        btnKembali.addActionListener(e -> {
            frame.dispose();
            showMainMenu();
        });

        frame.setVisible(true);
    }

    private void showFormResep() {
        frame = new JFrame("Form Resep dan Pelayanan Pasien");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField tfNamaPasien = new JTextField(20);
        taResep = new JTextArea(10, 30);
        JButton btnSimpan = new JButton("Simpan Resep");
        String resep = taResep.getText();
        daftarResep.add(resep);

        JButton btnKembali = new JButton("Kembali");

        frame.add(new JLabel("Nama Pasien:"));
        frame.add(tfNamaPasien);
        frame.add(new JLabel("Resep:"));
        frame.add(new JScrollPane(taResep));
        frame.add(btnSimpan);
        frame.add(btnKembali);

        btnSimpan.addActionListener(e -> {
            // Di sini kita bisa menyimpan resep ke database atau struktur data lainnya
            JOptionPane.showMessageDialog(frame, "Resep disimpan!");
        });

        btnKembali.addActionListener(e -> {
            frame.dispose();
            showMainMenu();
        });

        frame.setVisible(true);
    }
    private void showDashboard() {
        frame = new JFrame("Dashboard");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel lblTotalObat = new JLabel("Total Obat: " + daftarObat.size());
        JLabel lblTotalResep = new JLabel("Total Resep: " + daftarResep.size());
        JButton btnKembali = new JButton("Kembali");

        frame.add(lblTotalObat);
        frame.add(lblTotalResep);
        frame.add(btnKembali);

        btnKembali.addActionListener(e -> {
            frame.dispose();
            showMainMenu();
        });

        frame.setVisible(true);
    }
    private void showLaporan() {
        frame = new JFrame("Laporan Resep");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextArea taLaporan = new JTextArea(20, 40);
        taLaporan.setEditable(false);
        JButton btnKembali = new JButton("Kembali");

        frame.add(new JScrollPane(taLaporan));
        frame.add(btnKembali);

        StringBuilder sb = new StringBuilder();
        for (String resep : daftarResep) {
            sb.append(resep).append("\n");
        }
        taLaporan.setText(sb.toString());

        btnKembali.addActionListener(e -> {
            frame.dispose();
            showMainMenu();
        });

        frame.setVisible(true);
    }

}

